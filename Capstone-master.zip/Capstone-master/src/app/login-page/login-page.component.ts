import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';

@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.css']
})
export class LOGINPAGEComponent implements OnInit {
  constructor(private router: Router) { }
  trylogin() {
    this.router.navigate(['logged-in']);
    //this.router.navigateByUrl('/logged-in');
    
  }
  ngOnInit() {
  }
}
