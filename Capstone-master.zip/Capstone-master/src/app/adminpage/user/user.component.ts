import { Component, OnInit } from '@angular/core';
import { BankService } from './user.service';
import {BankCustomer} from './user';
@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  customers: BankCustomer[];
  constructor(private _BankService: BankService) { }
  ngOnInit(): void{
    this.getCustomer();
  }

  getCustomer(): void{
    this._BankService.getAllCustomer()
    .subscribe((customerData) => {this.customers = customerData, 
      console.log(customerData) }, 
    (error) => {
      console.log(error);
    })
  }

  

}
