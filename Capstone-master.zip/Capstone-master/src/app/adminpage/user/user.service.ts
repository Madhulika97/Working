import {Http, Response, RequestOptions, Headers} from '@angular/http';
import { Injectable} from '@angular/core';
import { Observable } from 'rxjs';
import { BankCustomer } from './user';
// import 'rxjs/add/operator/map';
// import 'rxjs/add/operator/catch';
//import { map } from 'rxjs/operators';
// import 'rxjs/Rx';
import { map, catchError } from 'rxjs/operators';
//import { HttpClient } from '@angular/common/http';


@Injectable()
export class BankService{
    constructor(private _httpService: Http){}
    getAllCustomer(): Observable<BankCustomer[]>{
        return this._httpService.get("http://localhost:8080/bankapi/api/customers")
        .pipe(map((response: Response) => response.json()))
        catchError(this.handleError);
        
    }
    private handleError(error: Response){
        return Observable.throw(error);
    }
    
}