export class BankCustomer{
 
    accountNumber: String;
    address: String;
    email: String;
    fullName: String;
    password: String;
    phoneNumber: Number;
}