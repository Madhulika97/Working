import {Http, RequestOptions, Headers} from '@angular/http';
import { Injectable} from '@angular/core';
import { Observable } from 'rxjs';
import { Customer } from './register-page';
// import 'rxjs/add/operator/map';
// import 'rxjs/add/operator/catch';
import { map } from 'rxjs/operators';
// import 'rxjs/Rx';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';

@Injectable()
export class BankService1{
    constructor(private _httpService: Http){}
    addCustomer(customer: Customer){
        let body=JSON.stringify(customer);
        let headers= new Headers({'Content-Type':'application/json'});
        let options = new RequestOptions({headers: headers});
        return this._httpService.post("http://localhost:8080/bankapi/api/register_customer",body,options);
    }
}