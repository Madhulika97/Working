import { Component, OnInit } from '@angular/core';
import { Customer } from './register-page';
import { BankService1 } from './register-page.service';


@Component({
    selector: 'app-register-page',
    templateUrl: './register-page.component.html',
    styleUrls: ['./register-page.component.css']
})
export class REGISTERPAGEComponent implements OnInit {
    customer = new Customer();
    constructor( private _BankService : BankService1) { }

    ngOnInit() {
    }
    addCustomer(): void{
        this._BankService.addCustomer(this.customer)
        .subscribe((response) => {console.log(response)}, (error) =>{
            console.log(error);
        });
    }
}
