export class Customer{
    
    accountNumber: String;
    address: String;
    email: String;
    fullName: String;
    password: String;
    phoneNumber: Number; 
}